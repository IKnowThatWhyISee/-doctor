package constant;

public class Message {

    public static final String MSG_CODE_MESSAGE = "Enter code: ";
    public static final String MSG_NAME_MESSAGE = "Enter name: ";
    public static final String MSG_Specialization_MESSAGE = "Enter Specialization: ";
    public static final String MSG_AVAILABILITY_MESSAGE = "Enter Availability: ";
    public static final String MSG_OPTION_MESSAGE = "Choose: ";
    public static final String MSG_CONFIRMATION_MESSAGE = "Do you want to continue ? Y/N :";
}
